from .vivlio import cli
def run():
    cli()