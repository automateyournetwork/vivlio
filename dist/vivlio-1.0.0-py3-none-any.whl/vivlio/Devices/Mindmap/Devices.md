
# Organization Devices
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-04-06T20:40:56Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:cb:bc:3c:51:7e
### Model: MS220-8P
### Network ID: L_739153288842211764
### Notes: 
### Product Type: switch
### Serial: Q2HP-MABW-XS49
### Tags: []
### [URL](https://n313.meraki.com/ac_net-switch/n/-oOIxb5e/manage/nodes/new_list/247165641052542)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-06-28T04:09:53Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:cb:bc:51:43:5c
### Model: MR53
### Network ID: L_739153288842212545
### Notes: 
### Product Type: wireless
### Serial: Q2MD-DNPT-TL4B
### Tags: []
### [URL](https://n313.meraki.com/Techlab-Demo-wir/n/D9te-b5e/manage/nodes/new_list/247165642425180)
## Name: TEST NAME
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-01-12T22:20:47Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: e0:55:3d:17:d5:1a
### Model: MX65
### Network ID: L_646829496481111254
### Notes: 
### Product Type: appliance
### Serial: Q2QN-WPR6-UJPL
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/Aardvark-Branch-/n/0jNvzbvc/manage/nodes/new_list/246656701814042)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-05-10T19:09:02Z
### Firmware: Not running configured version
### LAN IP: 10.10.23.250
### MAC: cc:03:d9:01:70:fb
### Model: VMX-M
### Network ID: N_646829496481188542
### Notes: 
### Product Type: appliance
### Serial: Q2DZ-225U-KDVU
### Tags: []
### [URL](https://n149.meraki.com/vmx_1.3_mike/n/bkWa_bvc/manage/nodes/new_list/224316897718523)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-05-10T20:20:39Z
### Firmware: Not running configured version
### LAN IP: 10.10.22.250
### MAC: cc:03:d9:01:cc:1b
### Model: VMX-M
### Network ID: N_646829496481188541
### Notes: 
### Product Type: appliance
### Serial: Q2DZ-6VAH-SGNZ
### Tags: []
### [URL](https://n149.meraki.com/vmx_1.2_mike/n/erllgavc/manage/nodes/new_list/224316897741851)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-05-10T23:36:29Z
### Firmware: Not running configured version
### LAN IP: 10.10.21.250
### MAC: cc:03:d9:01:cf:f1
### Model: VMX-M
### Network ID: N_646829496481187875
### Notes: 
### Product Type: appliance
### Serial: Q2DZ-T2Y7-NSCZ
### Tags: []
### [URL](https://n149.meraki.com/vmx_1.1_mike/n/mBSfkbvc/manage/nodes/new_list/224316897742833)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-12-03T03:24:31Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: cc:03:d9:01:77:28
### Model: VMX-M
### Network ID: L_646829496481112535
### Notes: 
### Product Type: appliance
### Serial: Q2DZ-Y8FL-W85B
### Tags: []
### [URL](https://n149.meraki.com/MERAKI-FRIDAY-ap/n/ji8rpcvc/manage/nodes/new_list/224316897720104)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-23T01:50:51Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:55:3d:10:42:8a
### Model: MR84
### Network ID: L_646829496481113159
### Notes: 
### Product Type: wireless
### Serial: Q2EK-S3AA-BXFW
### Tags: []
### [URL](https://n149.meraki.com/Explore-Projects/n/7slgpcvc/manage/nodes/new_list/246656701317770)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-12-03T03:23:31Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 34:56:fe:a2:58:89
### Model: MV12WE
### Network ID: L_646829496481112535
### Notes: 
### Product Type: camera
### Serial: Q2FV-4QSY-KBF6
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/MERAKI-FRIDAY-ca/n/RaVb6dvc/manage/nodes/new_list/57548243884169)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-18T04:05:54Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 34:56:fe:a2:58:83
### Model: MV12WE
### Network ID: L_646829496481113133
### Notes: 
### Product Type: camera
### Serial: Q2FV-TG7N-MF4E
### Tags: []
### [URL](https://n149.meraki.com/DNENT2-axxxxxxx8/n/s4Zprbvc/manage/nodes/new_list/57548243884163)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-16T16:10:59Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 34:56:fe:a2:58:86
### Model: MV12WE
### Network ID: L_646829496481113110
### Notes: 
### Product Type: camera
### Serial: Q2FV-W72R-U7WX
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/DNENT3-gxxxxxlgm/n/AimLRbvc/manage/nodes/new_list/57548243884166)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-11T17:43:29Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 00:18:0a:84:77:e2
### Model: MR18
### Network ID: L_646829496481113068
### Notes: 
### Product Type: wireless
### Serial: Q2GD-3GCM-KSQ8
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/CCNP-SABADO-wire/n/JEme-avc/manage/nodes/new_list/8681442)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-16T16:10:54Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 34:56:fe:a5:6c:20
### Model: MS225-24P
### Network ID: L_646829496481113110
### Notes: 
### Product Type: switch
### Serial: Q2GW-2CA5-RW6A
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/DNENT3-gxxxxxlgm/n/b6sUWdvc/manage/nodes/new_list/57548244085792)
## Name: SW01-TEST-NEW-NAME
### Location
#### Address: 923 Valley Farms Avenue Lafayette, IN 47905
#### Latitude: 40.4064351
#### Longitude: -86.761749
### Configuration Updated At: 2023-01-13T02:21:31Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 34:56:fe:a5:6d:20
### Model: MS225-24P
### Network ID: L_646829496481112797
### Notes: 
### Product Type: switch
### Serial: Q2GW-2CPC-JCYZ
### Tags: ['recently-added', 'switches', 'test-tag']
### [URL](https://n149.meraki.com/CCNP-SCOR-switch/n/BW5c6cvc/manage/nodes/new_list/57548244086048)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-18T04:05:48Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 34:56:fe:a5:8a:20
### Model: MS225-24P
### Network ID: L_646829496481113133
### Notes: 
### Product Type: switch
### Serial: Q2GW-2WW9-LLZC
### Tags: []
### [URL](https://n149.meraki.com/DNENT2-axxxxxxx8/n/FwiN7bvc/manage/nodes/new_list/57548244093472)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-23T02:20:40Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 88:15:44:df:76:d1
### Model: MS220-8P
### Network ID: L_646829496481113160
### Notes: 
### Product Type: switch
### Serial: Q2HP-AJ22-UG72
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/DNSMB4-mxxxxxxko/n/8Q8SBavc/manage/nodes/new_list/149624931186385)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-02-10T13:58:35Z
### Firmware: switch-11-31
### LAN IP: 10.10.10.131
### MAC: 88:15:44:df:f3:af
### Model: MS220-8P
### Network ID: L_646829496481105433
### Notes: 
### Product Type: switch
### Serial: Q2HP-F5K5-R88R
### Tags: []
### [URL](https://n149.meraki.com/DevNet-Sandbox-A/n/EFZ1Davc/manage/nodes/new_list/149624931218351)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-11T17:44:25Z
### Firmware: switch-14-33-1
### LAN IP: 192.168.0.3
### MAC: 0c:8d:db:80:71:99
### Model: MS220-8P
### Network ID: L_646829496481113068
### Notes: 
### Product Type: switch
### Serial: Q2HP-JBEW-FN7B
### Tags: []
### [URL](https://n149.meraki.com/CCNP-SABADO-swit/n/OjLj5dvc/manage/nodes/new_list/13803412550041)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-23T01:50:43Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:55:3d:d2:e6:cd
### Model: MS220-8P
### Network ID: L_646829496481113159
### Notes: 
### Product Type: switch
### Serial: Q2HP-Q9S8-BVHB
### Tags: []
### [URL](https://n149.meraki.com/Explore-Projects/n/b0A2gavc/manage/nodes/new_list/246656714073805)
## Name: MS220-01
### Location
#### Address: 
#### Latitude: 37.41809396932946
#### Longitude: -122.0985318068415
### Configuration Updated At: 2023-02-20T02:19:46Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 88:15:44:df:fe:8e
### Model: MS220-8P
### Network ID: L_646829496481113141
### Notes: 
### Product Type: switch
### Serial: Q2HP-WH5E-MK7H
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/DNSMB2-axxxxhme./n/LHy40dvc/manage/nodes/new_list/149624931221134)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-01-13T01:54:14Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:55:3d:ae:0f:10
### Model: MR32
### Network ID: L_646829496481112797
### Notes: 
### Product Type: wireless
### Serial: Q2JD-3J97-QQYK
### Tags: []
### [URL](https://n149.meraki.com/CCNP-SCOR-wirele/n/rG-oudvc/manage/nodes/new_list/246656711659280)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-23T02:20:42Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:55:3d:1f:a7:10
### Model: MR32
### Network ID: L_646829496481113160
### Notes: 
### Product Type: wireless
### Serial: Q2JD-CAF3-Y6G2
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/DNSMB4-mxxxxxxko/n/czML1dvc/manage/nodes/new_list/246656702326544)
## Name: MR32-01
### Location
#### Address: Thane
#### Latitude: 19.21833
#### Longitude: 72.97809
### Configuration Updated At: 2023-01-18T15:00:40Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:55:3d:21:26:60
### Model: MR32
### Network ID: L_646829496481112860
### Notes: 
### Product Type: wireless
### Serial: Q2JD-N9K5-3QRB
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/Meraki-Emilio-wi/n/JLB3Gdvc/manage/nodes/new_list/246656702424672)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-09-15T00:21:05Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: e0:55:3d:e9:98:d0
### Model: MX100
### Network ID: L_646829496481111955
### Notes: 
### Product Type: appliance
### Serial: Q2JN-P6MT-PPZ5
### Tags: []
### [URL](https://n149.meraki.com/Teslag.Meraki.co/n/vhNLVcvc/manage/nodes/new_list/246656715561168)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-11-26T22:28:58Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 0c:8d:db:b2:86:9c
### Model: MR52
### Network ID: L_646829496481112509
### Notes: 
### Product Type: wireless
### Serial: Q2LD-98WJ-743V
### Tags: []
### [URL](https://n149.meraki.com/Teslag-Meraki-CC/n/ZPZ0Scvc/manage/nodes/new_list/13803415832220)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-18T03:43:21Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 88:15:44:60:20:a8
### Model: MR53
### Network ID: L_646829496481113132
### Notes: 
### Product Type: wireless
### Serial: Q2MD-9PJD-E9L7
### Tags: []
### [URL](https://n149.meraki.com/DNSMB5-xxxxxx6st/n/Nuensbvc/manage/nodes/new_list/149624922841256)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-12-03T03:24:16Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:cb:bc:51:42:78
### Model: MR53
### Network ID: L_646829496481112535
### Notes: 
### Product Type: wireless
### Serial: Q2MD-AAKS-ZQ4Y
### Tags: []
### [URL](https://n149.meraki.com/MERAKI-FRIDAY-wi/n/WupScavc/manage/nodes/new_list/247165642424952)
## Name: Testing-Devnet
### Location
#### Address: Puri Kharisma
#### Latitude: -6.978176264197443
#### Longitude: 107.63147611621667
### Configuration Updated At: 2022-01-28T06:00:58Z
### Firmware: wireless-26-6-1
### LAN IP: None
### MAC: 88:15:44:60:21:10
### Model: MR53
### Network ID: L_646829496481105433
### Notes: 
### Product Type: wireless
### Serial: Q2MD-BHHS-5FDL
### Tags: []
### [URL](https://n149.meraki.com/DevNet-Sandbox-A/n/raXeAcvc/manage/nodes/new_list/149624922841360)
## Name: DNENT3-MR53
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-16T16:10:57Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:cb:bc:51:45:80
### Model: MR53
### Network ID: L_646829496481113110
### Notes: 
### Product Type: wireless
### Serial: Q2MD-MFNY-6L6H
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/DNENT3-gxxxxxlgm/n/Ve0G0cvc/manage/nodes/new_list/247165642425728)
## Name: NEW-AP-01
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-18T04:05:50Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:cb:bc:51:28:f2
### Model: MR53
### Network ID: L_646829496481113133
### Notes: 
### Product Type: wireless
### Serial: Q2MD-Y5QK-LAK2
### Tags: ['AP_1stFLOOR', 'recently-added']
### [URL](https://n149.meraki.com/DNENT2-axxxxxxx8/n/nELH1bvc/manage/nodes/new_list/247165642418418)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-11-26T16:48:53Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:55:3d:f3:43:a8
### Model: MR33
### Network ID: L_646829496481112508
### Notes: 
### Product Type: wireless
### Serial: Q2PD-HQF8-UL4P
### Tags: []
### [URL](https://n149.meraki.com/P-Net-wireless/n/pAqjnavc/manage/nodes/new_list/246656716194728)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-17T02:42:40Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: 88:15:44:9e:8e:10
### Model: MX84
### Network ID: L_646829496481113118
### Notes: 
### Product Type: appliance
### Serial: Q2PN-JRAG-STZY
### Tags: []
### [URL](https://n149.meraki.com/DNENT1-txxxxxvgm/n/f9X50avc/manage/nodes/new_list/149624926932496)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-16T16:10:51Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: e0:55:3d:11:c1:d0
### Model: MX84
### Network ID: L_646829496481113110
### Notes: 
### Product Type: appliance
### Serial: Q2PN-PSMX-KDDC
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/DNENT3-gxxxxxlgm/n/2C_Y8avc/manage/nodes/new_list/246656701415888)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-18T04:05:45Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: e0:55:3d:2b:ef:a0
### Model: MX84
### Network ID: L_646829496481113133
### Notes: 
### Product Type: appliance
### Serial: Q2PN-WWNM-JRAS
### Tags: []
### [URL](https://n149.meraki.com/DNENT2-axxxxxxx8/n/ittSHbvc/manage/nodes/new_list/246656703131552)
## Name: MX 65
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-01-17T17:43:13Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: e0:55:3d:17:d4:23
### Model: MX65
### Network ID: L_646829496481105433
### Notes: 
### Product Type: appliance
### Serial: Q2QN-9J8L-SLPD
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/DevNet-Sandbox-A/n/9tIK5cvc/manage/nodes/new_list/246656701813795)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-11-26T22:28:33Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: 0c:8d:db:b0:64:1a
### Model: MX65
### Network ID: L_646829496481112509
### Notes: 
### Product Type: appliance
### Serial: Q2QN-ASVB-RJW3
### Tags: []
### [URL](https://n149.meraki.com/Teslag-Meraki-CC/n/SdU-kdvc/manage/nodes/new_list/13803415692314)
## Name: MX65
### Location
#### Address: 1205 Georgia ave,
#### Latitude: 38.91627
#### Longitude: -77.02191
### Configuration Updated At: 2023-02-23T01:50:39Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: e0:55:3d:70:ad:86
### Model: MX65
### Network ID: L_646829496481113159
### Notes: 
### Product Type: appliance
### Serial: Q2QN-WS5Y-DN8E
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/Explore-Projects/n/XwQwHavc/manage/nodes/new_list/246656707636614)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-18T03:43:24Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: e0:55:3d:70:a4:d7
### Model: MX65
### Network ID: L_646829496481113132
### Notes: 
### Product Type: appliance
### Serial: Q2QN-XPL2-2MPN
### Tags: []
### [URL](https://n149.meraki.com/DNSMB5-xxxxxx6st/n/kAJMrbvc/manage/nodes/new_list/246656707634391)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-23T01:50:47Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:55:3d:f4:39:17
### Model: MR30H
### Network ID: L_646829496481113159
### Notes: 
### Product Type: wireless
### Serial: Q2RD-4YLL-CSUN
### Tags: []
### [URL](https://n149.meraki.com/Explore-Projects/n/7slgpcvc/manage/nodes/new_list/246656716257559)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-01-21T01:07:59Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: ac:17:c8:1a:0f:e1
### Model: MX65W
### Network ID: L_646829496481112860
### Notes: 
### Product Type: appliance
### Serial: Q2RN-FZBT-UU4U
### Tags: []
### [URL](https://n149.meraki.com/Meraki-Emilio-ap/n/fiJmxdvc/manage/nodes/new_list/189218141376481)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-01-13T01:54:34Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: 4c:c8:a1:01:00:dc
### Model: MX68W
### Network ID: L_646829496481112797
### Notes: 
### Product Type: appliance
### Serial: QBSA-NZGF-XVSU
### Tags: []
### [URL](https://n149.meraki.com/CCNP-SCOR-applia/n/bGTPAdvc/manage/nodes/new_list/84424578367708)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-11T17:42:24Z
### Firmware: Not running configured version
### LAN IP: 
### MAC: 4c:c8:a1:00:00:dc
### Model: MX67
### Network ID: L_646829496481113068
### Notes: 
### Product Type: appliance
### Serial: QBSA-Z88Z-GP8H
### Tags: []
### [URL](https://n149.meraki.com/CCNP-SABADO-appl/n/6JTG_bvc/manage/nodes/new_list/84424578302172)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-11-26T16:46:17Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 4c:c8:a1:09:00:dc
### Model: MS425-32
### Network ID: L_646829496481112508
### Notes: 
### Product Type: switch
### Serial: QBSB-9D3T-B4BX
### Tags: []
### [URL](https://n149.meraki.com/P-Net-switch/n/DVJPPbvc/manage/nodes/new_list/84424578891996)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-23T01:02:52Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 4c:c8:a1:05:00:dc
### Model: MS120-8FP
### Network ID: L_646829496481112535
### Notes: 
### Product Type: switch
### Serial: QBSB-V9F7-WABM
### Tags: ['recently-added']
### [URL](https://n149.meraki.com/MERAKI-FRIDAY-sw/n/pfDEJavc/manage/nodes/new_list/84424578629852)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-12-03T03:23:19Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 4c:c8:a1:0d:00:dc
### Model: MR53E
### Network ID: L_646829496481112535
### Notes: 
### Product Type: wireless
### Serial: QBSC-88DU-VVGN
### Tags: []
### [URL](https://n149.meraki.com/MERAKI-FRIDAY-wi/n/WupScavc/manage/nodes/new_list/84424579154140)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-12-03T03:24:04Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 4c:c8:a1:0e:00:dc
### Model: MR74
### Network ID: L_646829496481112535
### Notes: 
### Product Type: wireless
### Serial: QBSC-JW5H-LUFH
### Tags: []
### [URL](https://n149.meraki.com/MERAKI-FRIDAY-wi/n/WupScavc/manage/nodes/new_list/84424579219676)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-12-03T03:22:47Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 4c:c8:a1:0a:00:dc
### Model: MR20
### Network ID: L_646829496481112535
### Notes: 
### Product Type: wireless
### Serial: QBSC-ZFT7-KKKZ
### Tags: []
### [URL](https://n149.meraki.com/MERAKI-FRIDAY-wi/n/WupScavc/manage/nodes/new_list/84424578957532)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2023-02-11T17:44:47Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 4c:c8:a1:11:00:46
### Model: MV12N
### Network ID: L_646829496481113068
### Notes: 
### Product Type: camera
### Serial: QBSD-6Z53-VFXL
### Tags: []
### [URL](https://n149.meraki.com/CCNP-SABADO-came/n/cpksycvc/manage/nodes/new_list/84424579416134)
## Name: 
### Location
#### Address: 
#### Latitude: 37.4180951010362
#### Longitude: -122.098531723022
### Configuration Updated At: 2022-06-08T17:50:01Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: 4c:c8:a1:10:00:78
### Model: MV12WE
### Network ID: N_646829496481189507
### Notes: 
### Product Type: camera
### Serial: QBSD-TQ9A-4DLS
### Tags: []
### [URL](https://n149.meraki.com/CLUS-22/n/yRKR8cvc/manage/nodes/new_list/84424579350648)
## Name: 
### Location
#### Address: 
#### Latitude: 37.41344244368212
#### Longitude: -122.09170818328859
### Configuration Updated At: 2022-04-08T18:57:46Z
### Firmware: Not running configured version
### LAN IP: None
### MAC: e0:cb:bc:3c:51:89
### Model: MS220-8P
### Network ID: N_739153288842289643
### Notes: 
### Product Type: switch
### Serial: Q2HP-M5HX-AXQL
### Tags: []
### [URL](https://n313.meraki.com/BRU-3/n/s6W3Bd5e/manage/nodes/new_list/247165641052553)
## Name: ms220-8p a9:b1
### Location
#### Address: 
#### Latitude: 37.41884921333153
#### Longitude: -122.09829837083818
### Configuration Updated At: 2022-04-09T15:03:22Z
### Firmware: Not running configured version
### LAN IP: 192.168.0.4
### MAC: e0:55:3d:d1:a9:b1
### Model: MS220-8P
### Network ID: N_739153288842289643
### Notes: 
### Product Type: switch
### Serial: Q2HP-TQPZ-M5LP
### Tags: []
### [URL](https://n313.meraki.com/BRU-3/n/s6W3Bd5e/manage/nodes/new_list/246656713992625)