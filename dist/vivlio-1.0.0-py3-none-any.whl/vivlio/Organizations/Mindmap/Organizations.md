
# Organizations
## ID: 739153288842183504
### Name: R4-Sam
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/ptyaid5e/manage/organization/overview)
## ID: 739153288842184109
### Name: Devnet-GroupAlpha
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/EOKxfc5e/manage/organization/overview)
## ID: 739153288842183396
### Name: KFC
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: per-device
### Management Details: []
### [URL](https://n313.meraki.com/o/fEM06d5e/manage/organization/overview)
## ID: 739153288842183894
### Name: Bakwas
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/GuoNWd5e/manage/organization/overview)
## ID: 739153288842183620
### Name: Foresightbob
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/0-xfCa5e/manage/organization/overview)
## ID: 739153288842183262
### Name: Timisoara
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/yFifib5e/manage/organization/overview)
## ID: 739153288842183354
### Name: Testing123
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/x-L8jc5e/manage/organization/overview)
## ID: 739153288842184112
### Name: Devnet-GroupBeta
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/pEaeHd5e/manage/organization/overview)
## ID: 739153288842183257
### Name: Meraki_K
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: per-device
### Management Details: []
### [URL](https://n313.meraki.com/o/coiqQb5e/manage/organization/overview)
## ID: 739153288842184307
### Name: DaisyLeeTest
### Enabled: False
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/97UULb5e/manage/organization/overview)
## ID: 739153288842184111
### Name: Devnet-GroupBeta
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/htAL3a5e/manage/organization/overview)
## ID: 739153288842184574
### Name: Artemis Organization
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/ahcGld5e/manage/organization/overview)
## ID: 739153288842184577
### Name: Artemis Organization
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/wM8lld5e/manage/organization/overview)
## ID: 739153288842183778
### Name: ducTran
### Enabled: False
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/3LuZ1a5e/manage/organization/overview)
## ID: 739153288842183333
### Name: DevNet Sandbox2
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: per-device
### Management Details: []
### [URL](https://n313.meraki.com/o/IgKItc5e/manage/organization/overview)
## ID: 646829496481090633
### Name: PNCE Sandbox 01
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/xhrYOavc/manage/organization/overview)
## ID: 959854
### Name: Devnet-VM
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: per-device
### Management Details: []
### [URL](https://n313.meraki.com/o/Aelgwd/manage/organization/overview)
## ID: 739153288842184115
### Name: Diego-Test2
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/NUlu2d5e/manage/organization/overview)
## ID: 739153288842183647
### Name: MB-Sandbox
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/6q8Gvc5e/manage/organization/overview)
## ID: 739153288842183516
### Name: Test_ked
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/7sWEla5e/manage/organization/overview)
## ID: 739153288842183661
### Name: NB
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/68zryc5e/manage/organization/overview)
## ID: 739153288842184136
### Name: Lab_ECMS_PREP
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/IBw0_d5e/manage/organization/overview)
## ID: 739153288842183388
### Name: NTT LAB (US)
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/1hDc-d5e/manage/organization/overview)
## ID: 739153288842184121
### Name: Devnet-GroupGamma2
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/vUygud5e/manage/organization/overview)
## ID: 739153288842183615
### Name: NorbertTest
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/EK3Toa5e/manage/organization/overview)
## ID: 739153288842184492
### Name: anv
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/KbffDa5e/manage/organization/overview)
## ID: 646829496481090432
### Name: IRI-BT-ORG
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/mLVx_cvc/manage/organization/overview)
## ID: 646829496481090616
### Name: Co-management test CW
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/UO_Kvavc/manage/organization/overview)
## ID: 1030307
### Name: Devnet-GroupDelta
### Enabled: True
### Cloud Region Name: Europe
### Licensing Model: co-term
### Management Details: []
### [URL](https://n201.meraki.com/o/fle9Ub/manage/organization/overview)
## ID: 1055430
### Name: WARRAQ
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n109.meraki.com/o/Mgjx2c/manage/organization/overview)
## ID: 1057293
### Name: meraki_test_reston
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: per-device
### Management Details: []
### [URL](https://n109.meraki.com/o/97hh3c/manage/organization/overview)
## ID: 1062199
### Name: OPLK 
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n385.meraki.com/o/Svs4xa/manage/organization/overview)
## ID: 624311498344236932
### Name: ericrod2
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n109.meraki.com/o/uz0IlaTb/manage/organization/overview)
## ID: 739153288842184053
### Name: Nomios-NTA
### Enabled: False
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/Ul-zzc5e/manage/organization/overview)
## ID: 739153288842183874
### Name: Xmzx
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: per-device
### Management Details: []
### [URL](https://n313.meraki.com/o/6ikmgc5e/manage/organization/overview)
## ID: 646829496481089956
### Name: Sam_Test
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/eJXnFcvc/manage/organization/overview)
## ID: 646829496481090058
### Name: RD networks
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/VhzFrbvc/manage/organization/overview)
## ID: 646829496481090062
### Name: Meraki-J
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/dimMtbvc/manage/organization/overview)
## ID: 646829496481090077
### Name: CZ-TB-Test
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/MoEANavc/manage/organization/overview)
## ID: 646829496481090100
### Name: mh_test
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/cSTuAdvc/manage/organization/overview)
## ID: 646829496481090148
### Name: greger
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/TMG4Idvc/manage/organization/overview)
## ID: 646829496481090153
### Name: Sandbox Test 
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/UkKd_dvc/manage/organization/overview)
## ID: 646829496481090182
### Name: GERIS
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: per-device
### Management Details: []
### [URL](https://n149.meraki.com/o/Gonhudvc/manage/organization/overview)
## ID: 646829496481090195
### Name: TestFel
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/HCQPjdvc/manage/organization/overview)
## ID: 646829496481090232
### Name: Osho_branch
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/GAvTwdvc/manage/organization/overview)
## ID: 646829496481090242
### Name: Grossetofficet
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/fY9mAavc/manage/organization/overview)
## ID: 646829496481090243
### Name: GTECH-ORG
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: per-device
### Management Details: []
### [URL](https://n149.meraki.com/o/0DU21dvc/manage/organization/overview)
## ID: 646829496481090303
### Name: EWO
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/4T-Hwavc/manage/organization/overview)
## ID: 646829496481090305
### Name: SummerOrg
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/rb1g_cvc/manage/organization/overview)
## ID: 646829496481090306
### Name: WinterOrg
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/V0GUacvc/manage/organization/overview)
## ID: 646829496481090341
### Name: SCCTest 
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/sLAe_bvc/manage/organization/overview)
## ID: 646829496481090413
### Name: APItest
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/t3CJFavc/manage/organization/overview)
## ID: 646829496481090419
### Name: devnetcoen
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/kV4Obcvc/manage/organization/overview)
## ID: 646829496481090420
### Name: devnetmeraki@cisco.com
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: per-device
### Management Details: []
### [URL](https://n149.meraki.com/o/A1tTCavc/manage/organization/overview)
## ID: 646829496481090424
### Name: api_test
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/-O4aCbvc/manage/organization/overview)
## ID: 646829496481090483
### Name: elieorg
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/PYiu_cvc/manage/organization/overview)
## ID: 646829496481090488
### Name: preetan
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/hCCh8cvc/manage/organization/overview)
## ID: 646829496481090489
### Name: preetan
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/khoMedvc/manage/organization/overview)
## ID: 646829496481090490
### Name: preetan
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/imn9ndvc/manage/organization/overview)
## ID: 646829496481090537
### Name: DomsOrg
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/oYfe8avc/manage/organization/overview)
## ID: 646829496481090548
### Name: My organization
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/OxszJbvc/manage/organization/overview)
## ID: 646829496481090550
### Name: MYORG
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/fspUadvc/manage/organization/overview)
## ID: 646829496481090598
### Name: Matheus
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/Cr2ducvc/manage/organization/overview)
## ID: 646829496481090599
### Name: Matheus-ORG
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/R330Icvc/manage/organization/overview)
## ID: 646829496481090615
### Name: TestCW
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/p0xLobvc/manage/organization/overview)
## ID: 646829496481090621
### Name: TTD
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/4mtasavc/manage/organization/overview)
## ID: 646829496481090886
### Name: Artemis Organization
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/M2ttHcvc/manage/organization/overview)
## ID: 646829496481090887
### Name: ericrod2_v2
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/_vPDMavc/manage/organization/overview)
## ID: 739153288842184055
### Name: RoumiKasparrovka
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/NjzS2b5e/manage/organization/overview)
## ID: 739153288842183824
### Name: Hello
### Enabled: False
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/ElTMbc5e/manage/organization/overview)
## ID: 739153288842183345
### Name: HELLO_API
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/3e5zsd5e/manage/organization/overview)
## ID: 739153288842183770
### Name: Stest
### Enabled: False
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/dEmQod5e/manage/organization/overview)
## ID: 739153288842183875
### Name: Magnet Masters
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/BQyfrb5e/manage/organization/overview)
## ID: 739153288842183178
### Name: lukas
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/t1p79d5e/manage/organization/overview)
## ID: 646829496481089711
### Name: IPA
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/mpwmFbvc/manage/organization/overview)
## ID: 739153288842183042
### Name: PAOK
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/U_yS5a5e/manage/organization/overview)
## ID: 646829496481090891
### Name: JoeBurrowFanClub
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/EPsgdcvc/manage/organization/overview)
## ID: 739153288842184127
### Name: Git-GroupOmicron2
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/gW-wBb5e/manage/organization/overview)
## ID: 739153288842183030
### Name: sampleNet
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/r14BKa5e/manage/organization/overview)
## ID: 739153288842183605
### Name: Chungus
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/2d0AFc5e/manage/organization/overview)
## ID: 739153288842183608
### Name: Richard
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/gtRY0c5e/manage/organization/overview)
## ID: 739153288842184202
### Name: Staging_Net
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/uo115c5e/manage/organization/overview)
## ID: 739153288842184064
### Name: MyOrganizacionCuscoPeru
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/NJPZNd5e/manage/organization/overview)
## ID: 739153288842184203
### Name: Staging_Net
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/fKBA8c5e/manage/organization/overview)
## ID: 739153288842184573
### Name: Artemis Organization
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/yAWPGb5e/manage/organization/overview)
## ID: 739153288842183325
### Name: Dxb_silicoon
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/eDIvSc5e/manage/organization/overview)
## ID: 739153288842184110
### Name: Devnet-GroupBeta
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/xqo51d5e/manage/organization/overview)
## ID: 739153288842184442
### Name: CB Test
### Enabled: False
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/gFhutc5e/manage/organization/overview)
## ID: 739153288842184137
### Name: RoadRunner
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/KZzTBd5e/manage/organization/overview)
## ID: 739153288842182989
### Name: Panenka Systems
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/jg-D5d5e/manage/organization/overview)
## ID: 739153288842184578
### Name: Artemis Organization
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/g4B0Kb5e/manage/organization/overview)
## ID: 739153288842183562
### Name: XORGX
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/KCyR1a5e/manage/organization/overview)
## ID: 739153288842183617
### Name: TestSD
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/fzk8Gd5e/manage/organization/overview)
## ID: 739153288842184253
### Name: Bodayngo
### Enabled: False
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/f_RFnb5e/manage/organization/overview)
## ID: 739153288842183131
### Name: My_ORG
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/Or-1Hb5e/manage/organization/overview)
## ID: 739153288842184114
### Name: Diego-Test
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/UPaDBd5e/manage/organization/overview)
## ID: 739153288842183268
### Name: MSP - Client A
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/6SsW2d5e/manage/organization/overview)
## ID: 739153288842184576
### Name: Artemis Organization
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/h8774d5e/manage/organization/overview)
## ID: 739153288842184245
### Name: NCH_TEST
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/3u_mOd5e/manage/organization/overview)
## ID: 739153288842183506
### Name: SeaLab2020
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/iZWXXb5e/manage/organization/overview)
## ID: 739153288842183144
### Name: Charles Uneze Organization
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/4JHvcd5e/manage/organization/overview)
## ID: 739153288842183281
### Name: my_new_test_meraki_org
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/6mmsbb5e/manage/organization/overview)
## ID: 739153288842184118
### Name: Diego-Test3
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/lb-4kc5e/manage/organization/overview)
## ID: 646829496481090277
### Name: Cargill_lab
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/1DPMMcvc/manage/organization/overview)
## ID: 739153288842184265
### Name: MuthanaAPITest
### Enabled: False
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/wP2i4c5e/manage/organization/overview)
## ID: 646829496481090304
### Name: Meraki_Ansible_Test
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/sVhqXcvc/manage/organization/overview)
## ID: 646829496481090261
### Name: SavTestOrganization
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/NxnxPcvc/manage/organization/overview)
## ID: 646829496481090437
### Name: BlueApple
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/qzHpmavc/manage/organization/overview)
## ID: 646829496481090622
### Name: TTD_NETWORK
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/IMt2tcvc/manage/organization/overview)
## ID: 646829496481090625
### Name: TronsGreen
### Enabled: False
### Cloud Region Name: North America
### Licensing Model: co-term
### Management Details: []
### [URL](https://n149.meraki.com/o/kf2bibvc/manage/organization/overview)
## ID: 549236
### Name: DevNet Sandbox
### Enabled: True
### Cloud Region Name: North America
### Licensing Model: per-device
### Management Details: []
### [URL](https://n149.meraki.com/o/-t35Mb/manage/organization/overview)
## ID: 739153288842184201
### Name: DevNet Sandbox
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/CBIG0c5e/manage/organization/overview)
## ID: 739153288842184348
### Name: FT4_DallasWest
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/SjP3Kd5e/manage/organization/overview)
## ID: 739153288842184715
### Name: WSDOG
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/6-Xsac5e/manage/organization/overview)
## ID: 739153288842183771
### Name: SuperNova
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/CSUSjc5e/manage/organization/overview)
## ID: 739153288842183142
### Name: KB
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: per-device
### Management Details: []
### [URL](https://n313.meraki.com/o/aS4jvc5e/manage/organization/overview)
## ID: 739153288842184255
### Name: My test organization
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/G0s96d5e/manage/organization/overview)
## ID: 739153288842184256
### Name: Phantom Technologies
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/TVoE7d5e/manage/organization/overview)
## ID: 739153288842184323
### Name: VM_TDS_LAB
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/KsHufb5e/manage/organization/overview)
## ID: 739153288842183222
### Name: XYZ
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/J-9OId5e/manage/organization/overview)
## ID: 739153288842183259
### Name: FiveFold-Org
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/Iz4zbb5e/manage/organization/overview)
## ID: 739153288842184015
### Name: tomtest
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/TU0u3c5e/manage/organization/overview)
## ID: 739153288842183353
### Name: ENAUTO
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/_HsfHc5e/manage/organization/overview)
## ID: 739153288842183777
### Name: ducTran
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/Qq3Hdc5e/manage/organization/overview)
## ID: 739153288842184177
### Name: DG
### Enabled: False
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/lpnDhd5e/manage/organization/overview)
## ID: 739153288842183652
### Name: mc25
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/E5fx3c5e/manage/organization/overview)
## ID: 739153288842183560
### Name: DunderMifflin
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/Vnr1ob5e/manage/organization/overview)
## ID: 739153288842183267
### Name: Nath_Meraki
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/O2uFwc5e/manage/organization/overview)
## ID: 739153288842184122
### Name: Devnet-GroupGamma
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/F-qNrb5e/manage/organization/overview)
## ID: 739153288842183338
### Name: MaxOrganization
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/bMtRGd5e/manage/organization/overview)
## ID: 739153288842183649
### Name: DevNetSandbox-J
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: per-device
### Management Details: []
### [URL](https://n313.meraki.com/o/vup0qa5e/manage/organization/overview)
## ID: 739153288842183237
### Name: Test_M_Org
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/t7F-md5e/manage/organization/overview)
## ID: 739153288842183561
### Name: DunderMifflinX
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/nTt5Qc5e/manage/organization/overview)
## ID: 739153288842183386
### Name: NTT LAB (EU)
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/Ln2VTc5e/manage/organization/overview)
## ID: 739153288842182990
### Name: My Enauto Org
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: per-device
### Management Details: []
### [URL](https://n313.meraki.com/o/k6FBjc5e/manage/organization/overview)
## ID: 739153288842184571
### Name: HLT-XX-WAN-XXXX-NA-XX
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/SG9Rqd5e/manage/organization/overview)
## ID: 739153288842183041
### Name: Cali Unified
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/o0Tqbc5e/manage/organization/overview)
## ID: 739153288842183233
### Name: test01
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/WjT2za5e/manage/organization/overview)
## ID: 739153288842183346
### Name: HELLO_API
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/5TRipb5e/manage/organization/overview)
## ID: 739153288842183264
### Name: SOCORP
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/Ya2x7b5e/manage/organization/overview)
## ID: 739153288842184116
### Name: Diego-Test3
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: per-device
### Management Details: []
### [URL](https://n313.meraki.com/o/DtYqEd5e/manage/organization/overview)
## ID: 739153288842183911
### Name: Niciu.com
### Enabled: False
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/4Cla6d5e/manage/organization/overview)
## ID: 739153288842184575
### Name: Artemis Organization
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/s_ydRa5e/manage/organization/overview)
## ID: 739153288842183278
### Name: my_new_test_meraki_org
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/VC9OFa5e/manage/organization/overview)
## ID: 739153288842183109
### Name: Second Test Organization
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/nm4Hpa5e/manage/organization/overview)
## ID: 739153288842183563
### Name: EMEAR ORG
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: per-device
### Management Details: []
### [URL](https://n313.meraki.com/o/mmzmXa5e/manage/organization/overview)
## ID: 739153288842183876
### Name: Magnetic Masters
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/43fM1c5e/manage/organization/overview)
## ID: 739153288842183359
### Name: ZAAZA
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/ga3Luc5e/manage/organization/overview)
## ID: 739153288842184254
### Name: My test organization
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/PdWQNc5e/manage/organization/overview)
## ID: 739153288842183614
### Name: Syrius_beta
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/Pv_R7c5e/manage/organization/overview)
## ID: 739153288842184340
### Name: MEZE
### Enabled: False
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/NbM60d5e/manage/organization/overview)
## ID: 739153288842183519
### Name: Prasad_testing
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/daSNLd5e/manage/organization/overview)
## ID: 739153288842184113
### Name: DevnetPrueba
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/zuqwfc5e/manage/organization/overview)
## ID: 739153288842183210
### Name: MYLAND_2021
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/0ODNOb5e/manage/organization/overview)
## ID: 739153288842183567
### Name: JMK Org Test
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/tj6xsd5e/manage/organization/overview)
## ID: 739153288842183275
### Name: Ragab
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/s78Gsd5e/manage/organization/overview)
## ID: 739153288842183112
### Name: Org_1
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/iE011b5e/manage/organization/overview)
## ID: 739153288842182996
### Name: This is a test
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/RqKCtb5e/manage/organization/overview)
## ID: 739153288842182988
### Name: My Enauto Org
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/qX2xRc5e/manage/organization/overview)
## ID: 739153288842184117
### Name: Diego-Test3
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/FuRv1a5e/manage/organization/overview)
## ID: 739153288842183833
### Name: YAS-12345
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/bPK6Lc5e/manage/organization/overview)
## ID: 739153288842183873
### Name: X_org
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: per-device
### Management Details: []
### [URL](https://n313.meraki.com/o/Vehcmc5e/manage/organization/overview)
## ID: 739153288842183895
### Name: CISCOMERAKI
### Enabled: True
### Cloud Region Name: Asia
### Licensing Model: co-term
### Management Details: []
### [URL](https://n313.meraki.com/o/d1EkSa5e/manage/organization/overview)