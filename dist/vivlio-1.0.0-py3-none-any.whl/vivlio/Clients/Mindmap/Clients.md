
# Network Clients
## ID: k960ecc
### Adaptive Policy Group: None
### Description: Iphone-ellen
### Device Type Prediction: None
### Timestamps
#### First Seen: 2023-02-12T04:25:34Z
#### Last Seen: 2023-02-23T17:23:32Z
### Group Policy 802.1x: None
### IP
#### v4: 192.168.0.12
#### v6: None
#### v6 Local: fe80:0:0:0:188e:59ac:7ad6:6cea
### MAC: 44:4a:db:22:4a:53
### Manufacturer: Apple
### Notes: None
### OS: None
### Recent Device
#### Connection: Wired
#### MAC: 0c:8d:db:80:71:99
#### Name: None
#### Serial: Q2HP-JBEW-FN7B
### SM Installed: False
### SSID: None
### Status: Online
### Switchport: 6
### Usage:
#### Received: 986401
#### Sent: 44485
#### Total: 1030887
### User: None
### VLAN: 1
## ID: k961f40
### Adaptive Policy Group: None
### Description: None
### Device Type Prediction: None
### Timestamps
#### First Seen: 2023-02-11T17:46:10Z
#### Last Seen: 2023-02-23T17:23:32Z
### Group Policy 802.1x: None
### IP
#### v4: 192.168.0.1
#### v6: None
#### v6 Local: None
### MAC: 74:da:da:93:3f:61
### Manufacturer: D-Link International
### Notes: None
### OS: None
### Recent Device
#### Connection: Wired
#### MAC: 0c:8d:db:80:71:99
#### Name: None
#### Serial: Q2HP-JBEW-FN7B
### SM Installed: False
### SSID: None
### Status: Online
### Switchport: 1
### Usage:
#### Received: 3850335
#### Sent: 11908698
#### Total: 15759034
### User: None
### VLAN: 1
## ID: k98e222
### Adaptive Policy Group: None
### Description: VanTz-Property
### Device Type Prediction: None
### Timestamps
#### First Seen: 2023-02-11T18:17:17Z
#### Last Seen: 2023-02-23T06:46:00Z
### Group Policy 802.1x: None
### IP
#### v4: 169.254.57.89
#### v6: None
#### v6 Local: fe80:0:0:0:b7a4:b783:fc69:4453
### MAC: 74:70:fd:76:25:b4
### Manufacturer: Intel
### Notes: None
### OS: None
### Recent Device
#### Connection: Wired
#### MAC: 0c:8d:db:80:71:99
#### Name: None
#### Serial: Q2HP-JBEW-FN7B
### SM Installed: False
### SSID: None
### Status: Offline
### Switchport: 2
### Usage:
#### Received: 4873
#### Sent: 511
#### Total: 5384
### User: None
### VLAN: 1
## ID: ka02139
### Adaptive Policy Group: None
### Description: None
### Device Type Prediction: None
### Timestamps
#### First Seen: 2023-02-11T17:46:10Z
#### Last Seen: 2023-02-23T17:23:32Z
### Group Policy 802.1x: None
### IP
#### v4: 192.168.0.100
#### v6: None
#### v6 Local: None
### MAC: 00:00:5e:00:01:01
### Manufacturer: ICANN, IANA Department
### Notes: None
### OS: None
### Recent Device
#### Connection: Wired
#### MAC: 0c:8d:db:80:71:99
#### Name: None
#### Serial: Q2HP-JBEW-FN7B
### SM Installed: False
### SSID: None
### Status: Online
### Switchport: 2
### Usage:
#### Received: 1
#### Sent: 1551
#### Total: 1552
### User: None
### VLAN: 1
## ID: kaa06d3
### Adaptive Policy Group: None
### Description: SM-R890
### Device Type Prediction: None
### Timestamps
#### First Seen: 2023-02-11T18:42:56Z
#### Last Seen: 2023-02-23T07:31:09Z
### Group Policy 802.1x: None
### IP
#### v4: 192.168.0.21
#### v6: None
#### v6 Local: fe80:0:0:0:8494:a8ff:fef9:56c8
### MAC: 86:94:a8:f9:56:c8
### Manufacturer: None
### Notes: None
### OS: None
### Recent Device
#### Connection: Wired
#### MAC: 0c:8d:db:80:71:99
#### Name: None
#### Serial: Q2HP-JBEW-FN7B
### SM Installed: False
### SSID: None
### Status: Offline
### Switchport: 1
### Usage:
#### Received: 2
#### Sent: 3
#### Total: 5
### User: None
### VLAN: 1
## ID: kb1c799
### Adaptive Policy Group: None
### Description: android-5db4e5052f7134eb
### Device Type Prediction: None
### Timestamps
#### First Seen: 2023-02-11T17:46:10Z
#### Last Seen: 2023-02-23T04:11:55Z
### Group Policy 802.1x: None
### IP
#### v4: 192.168.0.15
#### v6: None
#### v6 Local: fe80:0:0:0:4e1a:3dff:fe27:949
### MAC: 4c:1a:3d:27:09:49
### Manufacturer: GUANGDONG OPPO MOBILE...
### Notes: None
### OS: Android
### Recent Device
#### Connection: Wired
#### MAC: 0c:8d:db:80:71:99
#### Name: None
#### Serial: Q2HP-JBEW-FN7B
### SM Installed: False
### SSID: None
### Status: Offline
### Switchport: 6
### Usage:
#### Received: 689
#### Sent: 472
#### Total: 1161
### User: None
### VLAN: 1
## ID: kb9b7c3
### Adaptive Policy Group: None
### Description: None
### Device Type Prediction: None
### Timestamps
#### First Seen: 2023-02-11T17:46:10Z
#### Last Seen: 2023-02-23T17:23:32Z
### Group Policy 802.1x: None
### IP
#### v4: 192.168.1.1
#### v6: None
#### v6 Local: fe80:0:0:0:0:0:0:1
### MAC: 24:58:6e:c8:93:22
### Manufacturer: zte
### Notes: None
### OS: None
### Recent Device
#### Connection: Wired
#### MAC: 0c:8d:db:80:71:99
#### Name: None
#### Serial: Q2HP-JBEW-FN7B
### SM Installed: False
### SSID: None
### Status: Online
### Switchport: 6
### Usage:
#### Received: 1064
#### Sent: 3321
#### Total: 4386
### User: None
### VLAN: 1
## ID: kb903c3
### Adaptive Policy Group: None
### Description: None
### Device Type Prediction: None
### Timestamps
#### First Seen: 2023-02-11T17:46:10Z
#### Last Seen: 2023-02-23T17:21:57Z
### Group Policy 802.1x: None
### IP
#### v4: 192.168.1.50
#### v6: None
#### v6 Local: None
### MAC: 00:00:1b:1b:65:ba
### Manufacturer: Novell
### Notes: None
### OS: None
### Recent Device
#### Connection: Wired
#### MAC: 0c:8d:db:80:71:99
#### Name: None
#### Serial: Q2HP-JBEW-FN7B
### SM Installed: False
### SSID: None
### Status: Online
### Switchport: 5
### Usage:
#### Received: 532
#### Sent: 2107
#### Total: 2639
### User: None
### VLAN: 1
## ID: k13a788
### Adaptive Policy Group: None
### Description: vivo-1804
### Device Type Prediction: None
### Timestamps
#### First Seen: 2023-02-12T05:07:46Z
#### Last Seen: 2023-02-23T17:23:32Z
### Group Policy 802.1x: None
### IP
#### v4: 192.168.0.22
#### v6: None
#### v6 Local: fe80:0:0:0:22f7:7cff:fe32:c667
### MAC: 20:f7:7c:32:c6:67
### Manufacturer: vivo Mobile Communication
### Notes: None
### OS: None
### Recent Device
#### Connection: Wired
#### MAC: 0c:8d:db:80:71:99
#### Name: None
#### Serial: Q2HP-JBEW-FN7B
### SM Installed: False
### SSID: None
### Status: Online
### Switchport: 6
### Usage:
#### Received: 326136
#### Sent: 863285
#### Total: 1189421
### User: None
### VLAN: 1
## ID: kc189c8
### Adaptive Policy Group: None
### Description: Galaxy-Note8
### Device Type Prediction: None
### Timestamps
#### First Seen: 2023-02-11T17:46:10Z
#### Last Seen: 2023-02-23T17:23:32Z
### Group Policy 802.1x: None
### IP
#### v4: 192.168.0.6
#### v6: None
#### v6 Local: fe80:0:0:0:3a0a:fd89:225b:26a6
### MAC: 04:d6:aa:c8:93:84
### Manufacturer: Samsung(THAILAND)
### Notes: None
### OS: None
### Recent Device
#### Connection: Wired
#### MAC: 0c:8d:db:80:71:99
#### Name: None
#### Serial: Q2HP-JBEW-FN7B
### SM Installed: False
### SSID: None
### Status: Online
### Switchport: 2
### Usage:
#### Received: 2044636
#### Sent: 111007
#### Total: 2155643
### User: None
### VLAN: 1