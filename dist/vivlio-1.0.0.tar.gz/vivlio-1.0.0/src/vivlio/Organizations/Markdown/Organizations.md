# Organizations
| ID | Name | API Enabled | Cloud Region Name | Licensing Model | Management Details | URL |
| -- | ---- | ----------- | ----------------- | --------------- | ------------------ | --- |
| 739153288842183504 | R4-Sam | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/ptyaid5e/manage/organization/overview) |
| 739153288842184109 | Devnet-GroupAlpha | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/EOKxfc5e/manage/organization/overview) |
| 739153288842183396 | KFC | True | Asia | per-device | [] | [URL](https://n313.meraki.com/o/fEM06d5e/manage/organization/overview) |
| 739153288842183894 | Bakwas | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/GuoNWd5e/manage/organization/overview) |
| 739153288842183620 | Foresightbob | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/0-xfCa5e/manage/organization/overview) |
| 739153288842183262 | Timisoara | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/yFifib5e/manage/organization/overview) |
| 739153288842183354 | Testing123 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/x-L8jc5e/manage/organization/overview) |
| 739153288842184112 | Devnet-GroupBeta | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/pEaeHd5e/manage/organization/overview) |
| 739153288842183257 | Meraki_K | True | Asia | per-device | [] | [URL](https://n313.meraki.com/o/coiqQb5e/manage/organization/overview) |
| 739153288842184307 | DaisyLeeTest | False | Asia | co-term | [] | [URL](https://n313.meraki.com/o/97UULb5e/manage/organization/overview) |
| 739153288842184111 | Devnet-GroupBeta | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/htAL3a5e/manage/organization/overview) |
| 739153288842184574 | Artemis Organization | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/ahcGld5e/manage/organization/overview) |
| 739153288842184577 | Artemis Organization | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/wM8lld5e/manage/organization/overview) |
| 739153288842183778 | ducTran | False | Asia | co-term | [] | [URL](https://n313.meraki.com/o/3LuZ1a5e/manage/organization/overview) |
| 739153288842183333 | DevNet Sandbox2 | True | Asia | per-device | [] | [URL](https://n313.meraki.com/o/IgKItc5e/manage/organization/overview) |
| 646829496481090633 | PNCE Sandbox 01 | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/xhrYOavc/manage/organization/overview) |
| 959854 | Devnet-VM | True | Asia | per-device | [] | [URL](https://n313.meraki.com/o/Aelgwd/manage/organization/overview) |
| 739153288842184115 | Diego-Test2 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/NUlu2d5e/manage/organization/overview) |
| 739153288842183647 | MB-Sandbox | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/6q8Gvc5e/manage/organization/overview) |
| 739153288842183516 | Test_ked | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/7sWEla5e/manage/organization/overview) |
| 739153288842183661 | NB | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/68zryc5e/manage/organization/overview) |
| 739153288842184136 | Lab_ECMS_PREP | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/IBw0_d5e/manage/organization/overview) |
| 739153288842183388 | NTT LAB (US) | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/1hDc-d5e/manage/organization/overview) |
| 739153288842184121 | Devnet-GroupGamma2 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/vUygud5e/manage/organization/overview) |
| 739153288842183615 | NorbertTest | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/EK3Toa5e/manage/organization/overview) |
| 739153288842184492 | anv | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/KbffDa5e/manage/organization/overview) |
| 646829496481090432 | IRI-BT-ORG | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/mLVx_cvc/manage/organization/overview) |
| 646829496481090616 | Co-management test CW | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/UO_Kvavc/manage/organization/overview) |
| 1030307 | Devnet-GroupDelta | True | Europe | co-term | [] | [URL](https://n201.meraki.com/o/fle9Ub/manage/organization/overview) |
| 1055430 | WARRAQ | False | North America | co-term | [] | [URL](https://n109.meraki.com/o/Mgjx2c/manage/organization/overview) |
| 1057293 | meraki_test_reston | True | North America | per-device | [] | [URL](https://n109.meraki.com/o/97hh3c/manage/organization/overview) |
| 1062199 | OPLK  | False | North America | co-term | [] | [URL](https://n385.meraki.com/o/Svs4xa/manage/organization/overview) |
| 624311498344236932 | ericrod2 | True | North America | co-term | [] | [URL](https://n109.meraki.com/o/uz0IlaTb/manage/organization/overview) |
| 739153288842184053 | Nomios-NTA | False | Asia | co-term | [] | [URL](https://n313.meraki.com/o/Ul-zzc5e/manage/organization/overview) |
| 739153288842183874 | Xmzx | True | Asia | per-device | [] | [URL](https://n313.meraki.com/o/6ikmgc5e/manage/organization/overview) |
| 646829496481089956 | Sam_Test | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/eJXnFcvc/manage/organization/overview) |
| 646829496481090058 | RD networks | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/VhzFrbvc/manage/organization/overview) |
| 646829496481090062 | Meraki-J | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/dimMtbvc/manage/organization/overview) |
| 646829496481090077 | CZ-TB-Test | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/MoEANavc/manage/organization/overview) |
| 646829496481090100 | mh_test | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/cSTuAdvc/manage/organization/overview) |
| 646829496481090148 | greger | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/TMG4Idvc/manage/organization/overview) |
| 646829496481090153 | Sandbox Test  | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/UkKd_dvc/manage/organization/overview) |
| 646829496481090182 | GERIS | True | North America | per-device | [] | [URL](https://n149.meraki.com/o/Gonhudvc/manage/organization/overview) |
| 646829496481090195 | TestFel | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/HCQPjdvc/manage/organization/overview) |
| 646829496481090232 | Osho_branch | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/GAvTwdvc/manage/organization/overview) |
| 646829496481090242 | Grossetofficet | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/fY9mAavc/manage/organization/overview) |
| 646829496481090243 | GTECH-ORG | True | North America | per-device | [] | [URL](https://n149.meraki.com/o/0DU21dvc/manage/organization/overview) |
| 646829496481090303 | EWO | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/4T-Hwavc/manage/organization/overview) |
| 646829496481090305 | SummerOrg | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/rb1g_cvc/manage/organization/overview) |
| 646829496481090306 | WinterOrg | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/V0GUacvc/manage/organization/overview) |
| 646829496481090341 | SCCTest  | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/sLAe_bvc/manage/organization/overview) |
| 646829496481090413 | APItest | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/t3CJFavc/manage/organization/overview) |
| 646829496481090419 | devnetcoen | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/kV4Obcvc/manage/organization/overview) |
| 646829496481090420 | devnetmeraki@cisco.com | True | North America | per-device | [] | [URL](https://n149.meraki.com/o/A1tTCavc/manage/organization/overview) |
| 646829496481090424 | api_test | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/-O4aCbvc/manage/organization/overview) |
| 646829496481090483 | elieorg | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/PYiu_cvc/manage/organization/overview) |
| 646829496481090488 | preetan | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/hCCh8cvc/manage/organization/overview) |
| 646829496481090489 | preetan | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/khoMedvc/manage/organization/overview) |
| 646829496481090490 | preetan | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/imn9ndvc/manage/organization/overview) |
| 646829496481090537 | DomsOrg | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/oYfe8avc/manage/organization/overview) |
| 646829496481090548 | My organization | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/OxszJbvc/manage/organization/overview) |
| 646829496481090550 | MYORG | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/fspUadvc/manage/organization/overview) |
| 646829496481090598 | Matheus | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/Cr2ducvc/manage/organization/overview) |
| 646829496481090599 | Matheus-ORG | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/R330Icvc/manage/organization/overview) |
| 646829496481090615 | TestCW | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/p0xLobvc/manage/organization/overview) |
| 646829496481090621 | TTD | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/4mtasavc/manage/organization/overview) |
| 646829496481090886 | Artemis Organization | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/M2ttHcvc/manage/organization/overview) |
| 646829496481090887 | ericrod2_v2 | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/_vPDMavc/manage/organization/overview) |
| 739153288842184055 | RoumiKasparrovka | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/NjzS2b5e/manage/organization/overview) |
| 739153288842183824 | Hello | False | Asia | co-term | [] | [URL](https://n313.meraki.com/o/ElTMbc5e/manage/organization/overview) |
| 739153288842183345 | HELLO_API | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/3e5zsd5e/manage/organization/overview) |
| 739153288842183770 | Stest | False | Asia | co-term | [] | [URL](https://n313.meraki.com/o/dEmQod5e/manage/organization/overview) |
| 739153288842183875 | Magnet Masters | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/BQyfrb5e/manage/organization/overview) |
| 739153288842183178 | lukas | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/t1p79d5e/manage/organization/overview) |
| 646829496481089711 | IPA | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/mpwmFbvc/manage/organization/overview) |
| 739153288842183042 | PAOK | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/U_yS5a5e/manage/organization/overview) |
| 646829496481090891 | JoeBurrowFanClub | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/EPsgdcvc/manage/organization/overview) |
| 739153288842184127 | Git-GroupOmicron2 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/gW-wBb5e/manage/organization/overview) |
| 739153288842183030 | sampleNet | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/r14BKa5e/manage/organization/overview) |
| 739153288842183605 | Chungus | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/2d0AFc5e/manage/organization/overview) |
| 739153288842183608 | Richard | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/gtRY0c5e/manage/organization/overview) |
| 739153288842184202 | Staging_Net | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/uo115c5e/manage/organization/overview) |
| 739153288842184064 | MyOrganizacionCuscoPeru | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/NJPZNd5e/manage/organization/overview) |
| 739153288842184203 | Staging_Net | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/fKBA8c5e/manage/organization/overview) |
| 739153288842184573 | Artemis Organization | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/yAWPGb5e/manage/organization/overview) |
| 739153288842183325 | Dxb_silicoon | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/eDIvSc5e/manage/organization/overview) |
| 739153288842184110 | Devnet-GroupBeta | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/xqo51d5e/manage/organization/overview) |
| 739153288842184442 | CB Test | False | Asia | co-term | [] | [URL](https://n313.meraki.com/o/gFhutc5e/manage/organization/overview) |
| 739153288842184137 | RoadRunner | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/KZzTBd5e/manage/organization/overview) |
| 739153288842182989 | Panenka Systems | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/jg-D5d5e/manage/organization/overview) |
| 739153288842184578 | Artemis Organization | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/g4B0Kb5e/manage/organization/overview) |
| 739153288842183562 | XORGX | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/KCyR1a5e/manage/organization/overview) |
| 739153288842183617 | TestSD | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/fzk8Gd5e/manage/organization/overview) |
| 739153288842184253 | Bodayngo | False | Asia | co-term | [] | [URL](https://n313.meraki.com/o/f_RFnb5e/manage/organization/overview) |
| 739153288842183131 | My_ORG | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/Or-1Hb5e/manage/organization/overview) |
| 739153288842184114 | Diego-Test | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/UPaDBd5e/manage/organization/overview) |
| 739153288842183268 | MSP - Client A | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/6SsW2d5e/manage/organization/overview) |
| 739153288842184576 | Artemis Organization | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/h8774d5e/manage/organization/overview) |
| 739153288842184245 | NCH_TEST | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/3u_mOd5e/manage/organization/overview) |
| 739153288842183506 | SeaLab2020 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/iZWXXb5e/manage/organization/overview) |
| 739153288842183144 | Charles Uneze Organization | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/4JHvcd5e/manage/organization/overview) |
| 739153288842183281 | my_new_test_meraki_org | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/6mmsbb5e/manage/organization/overview) |
| 739153288842184118 | Diego-Test3 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/lb-4kc5e/manage/organization/overview) |
| 646829496481090277 | Cargill_lab | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/1DPMMcvc/manage/organization/overview) |
| 739153288842184265 | MuthanaAPITest | False | Asia | co-term | [] | [URL](https://n313.meraki.com/o/wP2i4c5e/manage/organization/overview) |
| 646829496481090304 | Meraki_Ansible_Test | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/sVhqXcvc/manage/organization/overview) |
| 646829496481090261 | SavTestOrganization | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/NxnxPcvc/manage/organization/overview) |
| 646829496481090437 | BlueApple | True | North America | co-term | [] | [URL](https://n149.meraki.com/o/qzHpmavc/manage/organization/overview) |
| 646829496481090622 | TTD_NETWORK | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/IMt2tcvc/manage/organization/overview) |
| 646829496481090625 | TronsGreen | False | North America | co-term | [] | [URL](https://n149.meraki.com/o/kf2bibvc/manage/organization/overview) |
| 549236 | DevNet Sandbox | True | North America | per-device | [] | [URL](https://n149.meraki.com/o/-t35Mb/manage/organization/overview) |
| 739153288842184201 | DevNet Sandbox | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/CBIG0c5e/manage/organization/overview) |
| 739153288842184348 | FT4_DallasWest | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/SjP3Kd5e/manage/organization/overview) |
| 739153288842184715 | WSDOG | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/6-Xsac5e/manage/organization/overview) |
| 739153288842183771 | SuperNova | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/CSUSjc5e/manage/organization/overview) |
| 739153288842183142 | KB | True | Asia | per-device | [] | [URL](https://n313.meraki.com/o/aS4jvc5e/manage/organization/overview) |
| 739153288842184255 | My test organization | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/G0s96d5e/manage/organization/overview) |
| 739153288842184256 | Phantom Technologies | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/TVoE7d5e/manage/organization/overview) |
| 739153288842184323 | VM_TDS_LAB | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/KsHufb5e/manage/organization/overview) |
| 739153288842183222 | XYZ | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/J-9OId5e/manage/organization/overview) |
| 739153288842183259 | FiveFold-Org | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/Iz4zbb5e/manage/organization/overview) |
| 739153288842184015 | tomtest | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/TU0u3c5e/manage/organization/overview) |
| 739153288842183353 | ENAUTO | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/_HsfHc5e/manage/organization/overview) |
| 739153288842183777 | ducTran | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/Qq3Hdc5e/manage/organization/overview) |
| 739153288842184177 | DG | False | Asia | co-term | [] | [URL](https://n313.meraki.com/o/lpnDhd5e/manage/organization/overview) |
| 739153288842183652 | mc25 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/E5fx3c5e/manage/organization/overview) |
| 739153288842183560 | DunderMifflin | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/Vnr1ob5e/manage/organization/overview) |
| 739153288842183267 | Nath_Meraki | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/O2uFwc5e/manage/organization/overview) |
| 739153288842184122 | Devnet-GroupGamma | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/F-qNrb5e/manage/organization/overview) |
| 739153288842183338 | MaxOrganization | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/bMtRGd5e/manage/organization/overview) |
| 739153288842183649 | DevNetSandbox-J | True | Asia | per-device | [] | [URL](https://n313.meraki.com/o/vup0qa5e/manage/organization/overview) |
| 739153288842183237 | Test_M_Org | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/t7F-md5e/manage/organization/overview) |
| 739153288842183561 | DunderMifflinX | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/nTt5Qc5e/manage/organization/overview) |
| 739153288842183386 | NTT LAB (EU) | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/Ln2VTc5e/manage/organization/overview) |
| 739153288842182990 | My Enauto Org | True | Asia | per-device | [] | [URL](https://n313.meraki.com/o/k6FBjc5e/manage/organization/overview) |
| 739153288842184571 | HLT-XX-WAN-XXXX-NA-XX | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/SG9Rqd5e/manage/organization/overview) |
| 739153288842183041 | Cali Unified | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/o0Tqbc5e/manage/organization/overview) |
| 739153288842183233 | test01 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/WjT2za5e/manage/organization/overview) |
| 739153288842183346 | HELLO_API | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/5TRipb5e/manage/organization/overview) |
| 739153288842183264 | SOCORP | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/Ya2x7b5e/manage/organization/overview) |
| 739153288842184116 | Diego-Test3 | True | Asia | per-device | [] | [URL](https://n313.meraki.com/o/DtYqEd5e/manage/organization/overview) |
| 739153288842183911 | Niciu.com | False | Asia | co-term | [] | [URL](https://n313.meraki.com/o/4Cla6d5e/manage/organization/overview) |
| 739153288842184575 | Artemis Organization | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/s_ydRa5e/manage/organization/overview) |
| 739153288842183278 | my_new_test_meraki_org | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/VC9OFa5e/manage/organization/overview) |
| 739153288842183109 | Second Test Organization | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/nm4Hpa5e/manage/organization/overview) |
| 739153288842183563 | EMEAR ORG | True | Asia | per-device | [] | [URL](https://n313.meraki.com/o/mmzmXa5e/manage/organization/overview) |
| 739153288842183876 | Magnetic Masters | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/43fM1c5e/manage/organization/overview) |
| 739153288842183359 | ZAAZA | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/ga3Luc5e/manage/organization/overview) |
| 739153288842184254 | My test organization | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/PdWQNc5e/manage/organization/overview) |
| 739153288842183614 | Syrius_beta | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/Pv_R7c5e/manage/organization/overview) |
| 739153288842184340 | MEZE | False | Asia | co-term | [] | [URL](https://n313.meraki.com/o/NbM60d5e/manage/organization/overview) |
| 739153288842183519 | Prasad_testing | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/daSNLd5e/manage/organization/overview) |
| 739153288842184113 | DevnetPrueba | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/zuqwfc5e/manage/organization/overview) |
| 739153288842183210 | MYLAND_2021 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/0ODNOb5e/manage/organization/overview) |
| 739153288842183567 | JMK Org Test | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/tj6xsd5e/manage/organization/overview) |
| 739153288842183275 | Ragab | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/s78Gsd5e/manage/organization/overview) |
| 739153288842183112 | Org_1 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/iE011b5e/manage/organization/overview) |
| 739153288842182996 | This is a test | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/RqKCtb5e/manage/organization/overview) |
| 739153288842182988 | My Enauto Org | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/qX2xRc5e/manage/organization/overview) |
| 739153288842184117 | Diego-Test3 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/FuRv1a5e/manage/organization/overview) |
| 739153288842183833 | YAS-12345 | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/bPK6Lc5e/manage/organization/overview) |
| 739153288842183873 | X_org | True | Asia | per-device | [] | [URL](https://n313.meraki.com/o/Vehcmc5e/manage/organization/overview) |
| 739153288842183895 | CISCOMERAKI | True | Asia | co-term | [] | [URL](https://n313.meraki.com/o/d1EkSa5e/manage/organization/overview) |